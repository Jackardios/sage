(function($){
	function YandexMapPolygonField($field) {
		this.init($field);
	}

	YandexMapPolygonField.prototype.init = function($field) {
		var $configInput = $field.find('input[name="acf-yandex-map-polygon-config"]');

		if ($configInput && $configInput.length) {
			var config = $configInput.val();

			if (config) {
				this.CONFIG = JSON.parse(config);
				this.CONFIG.polygonEditorConfig = {
					// Курсор в режиме добавления новых вершин.
					editorDrawingCursor: "crosshair",
					// Цвет заливки.
					fillColor: '#00FF00',
					// Цвет обводки.
					strokeColor: '#0000FF',
					// Ширина обводки.
					strokeWidth: 3
				}; 
				this.CONFIG.mapContainerId = this.CONFIG.id + '-map';
				this.CONFIG.$field = $field;
				this.CONFIG.$input = $field.find('input[name="' + this.CONFIG.name + '"]');
				console.dir(this.CONFIG);
				this.initializeMap();
			}
		}
	}
	
	YandexMapPolygonField.prototype.initializeMap = function() {
		const self = this;
		window.ymaps.ready(function() {
			self.YANDEX_MAP = new window.ymaps.Map(self.CONFIG.mapContainerId, {
				type: 'yandex#' + self.CONFIG.map_type,
                center: [parseFloat(self.CONFIG.center_lat), parseFloat(self.CONFIG.center_lng)],
                zoom: parseInt(self.CONFIG.zoom)
			});
    
			// disable touch event
			// if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
			// 		self.YANDEX_MAP.behaviors.disable('drag');
			// }

			var inputValue = self.CONFIG.$input.val();
			if (inputValue) {
				self.drawGeoObjects(JSON.parse(inputValue));
			}
			self.initializeButtons();
			// self.startPolygonDrawing();
        });
	}

	YandexMapPolygonField.prototype.drawGeoObjects = function(geoObjects) {
		const self = this;
		if (geoObjects && geoObjects.length) {
			$.each(geoObjects, function(i, geometry) {

				if (geometry.type === 'Polygon') {
					var polygon = new ymaps.Polygon(geometry.coordinates, {}, self.CONFIG.polygonEditorConfig);
					// Добавляем многоугольник на карту.
					self.YANDEX_MAP.geoObjects.add(polygon);

					// В режиме добавления новых вершин меняем цвет обводки многоугольника.
					var stateMonitor = new ymaps.Monitor(polygon.editor.state);
					stateMonitor.add("drawing", function (newValue) {
						polygon.options.set("strokeColor", newValue ? '#FF0000' : '#0000FF');
					});
				
					// Включаем режим редактирования с возможностью добавления новых вершин.
					polygon.editor.startDrawing();
				}
				
			});
		}
	};

	YandexMapPolygonField.prototype.startPolygonDrawing = function() {
			
		// Создаем многоугольник без вершин.
		var polygon = new ymaps.Polygon([], {}, this.CONFIG.polygonEditorConfig);

		// Добавляем многоугольник на карту.
		this.YANDEX_MAP.geoObjects.add(polygon);
	
		// В режиме добавления новых вершин меняем цвет обводки многоугольника.
		var stateMonitor = new ymaps.Monitor(polygon.editor.state);
		stateMonitor.add("drawing", function (newValue) {
			polygon.options.set("strokeColor", newValue ? '#FF0000' : '#0000FF');
		});
	
		// Включаем режим редактирования с возможностью добавления новых вершин.
		polygon.editor.startDrawing();
		this.currentDrawingPolygon = polygon;

		return polygon;
	}

	YandexMapPolygonField.prototype.stopPolygonDrawing = function( polygon = this.currentDrawingPolygon ) {
		if (polygon) {
			polygon.editor.stopDrawing();
		}
	}

	YandexMapPolygonField.prototype.initializeStartDrawingButton = function() {
		var $element = $('<a class="acf-button button button-primary" href="#">Добавить фигуру</a>');
		
		const self = this;
		$element.on('click', function() {
			if (self.currentDrawingPolygon) {
				self.stopPolygonDrawing(self.currentDrawingPolygon);
			}
			self.startPolygonDrawing();
		});

		return $element;
	}

	// YandexMapPolygonField.prototype.initializeStopDrawingButton = function() {
	// 	var $element = $('<a class="acf-button button button-primary" href="#">Завершить фигуру</a>');
		
	// 	const self = this;
	// 	$element.on('click', function() {
	// 		self.stopPolygonDrawing();
	// 	});

	// 	return $element;
	// }

	YandexMapPolygonField.prototype.initializeButtons = function() {
		var $startDrawingButton = this.initializeStartDrawingButton();
			// $stopDrawingButton = this.initializeStopDrawingButton();
		$('#' + this.CONFIG.mapContainerId).before($startDrawingButton);
	}

	YandexMapPolygonField.prototype.geoObjects = function () {
		var geoObjects = [];
		this.YANDEX_MAP.geoObjects.each(function(item) {
			geoObjects.push({
				type: item.geometry.getType(),
				coordinates: item.geometry.getCoordinates()
			});
		});
		return geoObjects;
	}

	YandexMapPolygonField.prototype.saveObjectsToField = function() {
		var geoObjects = this.geoObjects();
		this.CONFIG.$input.val(JSON.stringify(geoObjects));
		return geoObjects;
	}
	
	/**
	*  initialize_field
	*
	*  This function will initialize the $field.
	*
	*  @date	30/11/17
	*  @since	5.6.5
	*
	*  @param	n/a
	*  @return	n/a
	*/
	
	function initialize_field( $field ) {
		var yandexMapPolygonFields = [];
		$field.each(function() {
			yandexMapPolygonFields.push(new YandexMapPolygonField($(this)));
		})

		$("#post").submit(function() {
			$.each(yandexMapPolygonFields, function(i, yandexMapPolygonField) {
				yandexMapPolygonField.saveObjectsToField();
			});
		});

		window.yandexMapPolygonFields = yandexMapPolygonFields;
	}
	
	if( typeof acf.add_action !== 'undefined' ) {
	
		/*
		*  ready & append (ACF5)
		*
		*  These two events are called when a field element is ready for initizliation.
		*  - ready: on page load similar to $(document).ready()
		*  - append: on new DOM elements appended via repeater field or other AJAX calls
		*
		*  @param	n/a
		*  @return	n/a
		*/
		
		acf.add_action('ready_field/type=yandex_map_polygon', initialize_field);
		acf.add_action('append_field/type=yandex_map_polygon', initialize_field);
		
		
	} else {
		
		/*
		*  acf/setup_fields (ACF4)
		*
		*  These single event is called when a field element is ready for initizliation.
		*
		*  @param	event		an event object. This can be ignored
		*  @param	element		An element which contains the new HTML
		*  @return	n/a
		*/
		
		$(document).on('acf/setup_fields', function(e, postbox){
			
			// find all relevant fields
			$(postbox).find('.field[data-field_type="yandex_map_polygon"]').each(function(){
				
				// initialize
				initialize_field( $(this) );
				
			});
		
		});
	
	}

})(jQuery);
