(function($){
	var CONFIG, YANDEX_MAP;
	var currentDrawingPolygon;
	
	/**
	*  initialize_field
	*
	*  This function will initialize the $field.
	*
	*  @date	30/11/17
	*  @since	5.6.5
	*
	*  @param	n/a
	*  @return	n/a
	*/
	
	function initialize_field( $field ) {
		var $configInput = $field.find('input[name="acf-yandex-map-polygon-config"]');

		if ($configInput && $configInput.length) {
			var config = $configInput.val();

			if (config) {
				CONFIG = JSON.parse(config);
				CONFIG.mapContainerId = CONFIG.id + '-map';
				CONFIG.$field = $field;
				console.dir(CONFIG);
				initialize_map();
			}
		}
		//$field.doStuff();
		
	}

	// function initialize_start_drawing_button() {
	// 	var $element = $('<a class="acf-button button button-primary" href="#">Добавить фигуру</a>');
		
	// 	$element.on('click', function() {
	// 		if (currentDrawingPolygon) {
	// 			stopPolygonDrawing(currentDrawingPolygon);
	// 		}
	// 		currentDrawingPolygon = startPolygonDrawing();
	// 	});

	// 	return $element;
	// }

	// function initialize_stop_drawing_button() {
	// 	var $element = $('<a class="acf-button button button-primary" href="#">Завершить фигуру</a>');
		
	// 	$element.on('click', function() {
	// 		stopPolygonDrawing(currentDrawingPolygon);
	// 	});

	// 	return $element;
	// }

	// function initialize_buttons() {
	// 	var $startDrawingButton = initialize_start_drawing_button(),
	// 		$stopDrawingButton = initialize_stop_drawing_button();
	// 	CONFIG.$field.prepend($startDrawingButton, $stopDrawingButton);
	// }

	function initialize_map() {
		window.ymaps.ready(function() {
			YANDEX_MAP = new window.ymaps.Map(CONFIG.mapContainerId, {
				type: 'yandex#' + CONFIG.map_type,
                center: [parseFloat(CONFIG.center_lat), parseFloat(CONFIG.center_lng)],
                zoom: parseInt(CONFIG.zoom)
			});
    
            // disable touch event
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
                YANDEX_MAP.behaviors.disable('drag');
			}

			startPolygonDrawing();
        });
	}

	function startPolygonDrawing() {
			
		// Создаем многоугольник без вершин.
		var polygon = new ymaps.Polygon([], {}, {
			// Курсор в режиме добавления новых вершин.
			editorDrawingCursor: "crosshair",
			// Цвет заливки.
			fillColor: '#00FF00',
			// Цвет обводки.
			strokeColor: '#0000FF',
			// Ширина обводки.
			strokeWidth: 3
		});

		// Добавляем многоугольник на карту.
		YANDEX_MAP.geoObjects.add(polygon);
	
		// В режиме добавления новых вершин меняем цвет обводки многоугольника.
		var stateMonitor = new ymaps.Monitor(polygon.editor.state);
		stateMonitor.add("drawing", function (newValue) {
			polygon.options.set("strokeColor", newValue ? '#FF0000' : '#0000FF');
		});
	
		// Включаем режим редактирования с возможностью добавления новых вершин.
		polygon.editor.startDrawing();

		return polygon;
	}

	function stopPolygonDrawing( polygon = currentDrawingPolygon ) {
		if (polygon) {
			polygon.editor.stopDrawing();
		}
	}
	
	if( typeof acf.add_action !== 'undefined' ) {
	
		/*
		*  ready & append (ACF5)
		*
		*  These two events are called when a field element is ready for initizliation.
		*  - ready: on page load similar to $(document).ready()
		*  - append: on new DOM elements appended via repeater field or other AJAX calls
		*
		*  @param	n/a
		*  @return	n/a
		*/
		
		acf.add_action('ready_field/type=yandex_map_polygon', initialize_field);
		acf.add_action('append_field/type=yandex_map_polygon', initialize_field);
		
		
	} else {
		
		/*
		*  acf/setup_fields (ACF4)
		*
		*  These single event is called when a field element is ready for initizliation.
		*
		*  @param	event		an event object. This can be ignored
		*  @param	element		An element which contains the new HTML
		*  @return	n/a
		*/
		
		$(document).on('acf/setup_fields', function(e, postbox){
			
			// find all relevant fields
			$(postbox).find('.field[data-field_type="yandex_map_polygon"]').each(function(){
				
				// initialize
				initialize_field( $(this) );
				
			});
		
		});
	
	}

})(jQuery);
