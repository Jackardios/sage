(function($) {
  function YandexMapPlacemarkField($field) {
    this.init($field);
  }

  YandexMapPlacemarkField.prototype.init = function($field) {
    var $configInput = $field.find("input.acf-ymp-config");

    if ($configInput && $configInput.length) {
      var config = $configInput.val();

      if (config) {
        this.CONFIG = JSON.parse(config);
        var $mapContainer = $field.find(".acf-ymp-container");
        this.CONFIG.$mapContainer = $mapContainer;
        this.CONFIG.mapContainerId = $mapContainer[0].id;
        this.CONFIG.$field = $field;
        this.CONFIG.$input = $field.find("input.acf-ymp-input");
        this.initializeMap();
      }
    }
  };

  YandexMapPlacemarkField.prototype.initializeMap = function() {
    var self = this;
    window.ymaps.ready(function() {
      self.YANDEX_MAP = new window.ymaps.Map(self.CONFIG.mapContainerId, {
        type: "yandex#" + self.CONFIG.map_type,
        center: [
          parseFloat(self.CONFIG.center_lat),
          parseFloat(self.CONFIG.center_lng)
        ],
        zoom: parseInt(self.CONFIG.zoom)
      });

      // disable touch event
      // if (
      //   /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      //     navigator.userAgent
      //   )
      // ) {
      //   self.YANDEX_MAP.behaviors.disable("drag");
      // }

      var inputValue = self.CONFIG.$input.val();
      if (inputValue) {
        self.drawGeometry(JSON.parse(inputValue));
      }

      if (!self.currentEditingPlacemark) {
        self.createInitialPlacemark();
      }

      // add events
      self.YANDEX_MAP.events.add("click", function(e) {
        console.dir(self.currentEditingPlacemark);
        if (
          self.currentEditingPlacemark &&
          self.currentEditingPlacemark.geometry.getType() === "Point"
        ) {
          self.currentEditingPlacemark.geometry.setCoordinates(e.get("coords"));
          // self.currentEditingPlacemark.editor.startEditing();
        }
      });
    });
  };

  YandexMapPlacemarkField.prototype.drawGeometry = function(geometry) {
    if (geometry.type === "Point") {
      var placemark = new ymaps.Placemark(geometry.coordinates);
      this.YANDEX_MAP.geoObjects.add(placemark);
      this.YANDEX_MAP.setCenter(geometry.coordinates);
      placemark.editor.startEditing();
      this.currentEditingPlacemark = placemark;
    }
  };

  YandexMapPlacemarkField.prototype.createInitialPlacemark = function() {
    var placemark = new ymaps.Placemark([
      parseFloat(this.CONFIG.center_lat),
      parseFloat(this.CONFIG.center_lng)
    ]);

    this.YANDEX_MAP.geoObjects.add(placemark);

    // Включаем режим редактирования
    placemark.editor.startEditing();
    this.currentEditingPlacemark = placemark;

    return placemark;
  };

  YandexMapPlacemarkField.prototype.geoObjects = function() {
    var geoObjects = [];
    this.YANDEX_MAP.geoObjects.each(function(item) {
      geoObjects.push({
        type: item.geometry.getType(),
        coordinates: item.geometry.getCoordinates()
      });
    });
    return geoObjects;
  };

  YandexMapPlacemarkField.prototype.getPlacemark = function() {
    var geoObjects = this.geoObjects();
    return geoObjects[0];
  };

  YandexMapPlacemarkField.prototype.saveObjectsToField = function() {
    var placemark = this.getPlacemark();
    if (placemark && placemark.coordinates) {
      this.CONFIG.$input.val(JSON.stringify(placemark));
      return placemark;
    }

    this.CONFIG.$input.val("");
    return null;
  };

  /**
   *  initialize_field
   *
   *  This function will initialize the $field.
   *
   *  @date	30/11/17
   *  @since	5.6.5
   *
   *  @param	n/a
   *  @return	n/a
   */

  function initialize_field($field) {
    var YandexMapPlacemarkFields = [];
    $field.each(function() {
      YandexMapPlacemarkFields.push(new YandexMapPlacemarkField($(this)));
    });

    $("#post").submit(function() {
      $.each(YandexMapPlacemarkFields, function(i, YandexMapPlacemarkField) {
        YandexMapPlacemarkField.saveObjectsToField();
      });
    });

    window.YandexMapPlacemarkFields = YandexMapPlacemarkFields;
  }

  if (typeof acf.add_action !== "undefined") {
    /*
     *  ready & append (ACF5)
     *
     *  These two events are called when a field element is ready for initizliation.
     *  - ready: on page load similar to $(document).ready()
     *  - append: on new DOM elements appended via repeater field or other AJAX calls
     *
     *  @param	n/a
     *  @return	n/a
     */

    acf.add_action("ready_field/type=yandex_map_placemark", initialize_field);
    acf.add_action("append_field/type=yandex_map_placemark", initialize_field);
  } else {
    /*
     *  acf/setup_fields (ACF4)
     *
     *  These single event is called when a field element is ready for initizliation.
     *
     *  @param	event		an event object. This can be ignored
     *  @param	element		An element which contains the new HTML
     *  @return	n/a
     */

    $(document).on("acf/setup_fields", function(e, postbox) {
      // find all relevant fields
      $(postbox)
        .find('.field[data-field_type="yandex_map_placemark"]')
        .each(function() {
          // initialize
          initialize_field($(this));
        });
    });
  }
})(jQuery);
